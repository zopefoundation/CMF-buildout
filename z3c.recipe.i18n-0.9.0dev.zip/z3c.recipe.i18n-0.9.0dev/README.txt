***************
z3c.recipe.i18n
***************

This Zope 3 recipes offers different tools which allows to extract i18n 
translation messages from egg based packages.
